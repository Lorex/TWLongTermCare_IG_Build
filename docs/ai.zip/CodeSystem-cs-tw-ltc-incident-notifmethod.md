# 長照 SDK－異常紀錄－通報方式 - 臺灣長期照顧實作指引(TW LTC IG) v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **長照 SDK－異常紀錄－通報方式**

## CodeSystem: 長照 SDK－異常紀錄－通報方式 

| | |
| :--- | :--- |
| *Official URL*:http://ltc-ig.fhir.tw/CodeSystem/cs-tw-ltc-incident-notifmethod | *Version*:1.1.0 |
| Active as of 2026-09-29 | *Computable Name*:CS_TW_LTC_Incident_NotificationMethod |
| *Other Identifiers:*OID:2.25.258319038068702686220303557239347690932 | |

 
表單『通報方式』多選。 

 This Code system is referenced in the content logical definition of the following value sets: 

* [長照 SDK－異常紀錄－通報方式](ValueSet-vs-tw-ltc-incident-notifmethod.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "cs-tw-ltc-incident-notifmethod",
  "url" : "http://ltc-ig.fhir.tw/CodeSystem/cs-tw-ltc-incident-notifmethod",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.25.258319038068702686220303557239347690932"
  }],
  "version" : "1.1.0",
  "name" : "CS_TW_LTC_Incident_NotificationMethod",
  "title" : "長照 SDK－異常紀錄－通報方式",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-29T04:34:44+08:00",
  "publisher" : "經濟部產業發展署",
  "contact" : [{
    "name" : "經濟部產業發展署",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ida.gov.tw/"
    }]
  }],
  "description" : "表單『通報方式』多選。",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 7,
  "concept" : [{
    "code" : "phone",
    "display" : "電話"
  },
  {
    "code" : "inperson",
    "display" : "當面"
  },
  {
    "code" : "fax",
    "display" : "傳真"
  },
  {
    "code" : "org",
    "display" : "機構"
  },
  {
    "code" : "family",
    "display" : "家屬"
  },
  {
    "code" : "cgportal",
    "display" : "CG通報"
  },
  {
    "code" : "other",
    "display" : "其他"
  }]
}

```
