# 長照 SDK－申請來源（暫行） - 臺灣長期照顧實作指引(TW LTC IG) v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **長照 SDK－申請來源（暫行）**

## CodeSystem: 長照 SDK－申請來源（暫行） 

| | |
| :--- | :--- |
| *Official URL*:http://ltc-ig.fhir.tw/CodeSystem/cs-tw-ltc-case-source | *Version*:1.1.0 |
| Active as of 2026-09-17 | *Computable Name*:CS_TW_LTC_Case_Source |
| *Other Identifiers:*OID:2.25.190870353172104733550910222730752386044 | |

 
申請來源常見分類（待以 Excel 實值更新）。 

 This Code system is referenced in the content logical definition of the following value sets: 

* [長照 SDK－申請來源](ValueSet-vs-tw-ltc-case-source.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "cs-tw-ltc-case-source",
  "url" : "http://ltc-ig.fhir.tw/CodeSystem/cs-tw-ltc-case-source",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.25.190870353172104733550910222730752386044"
  }],
  "version" : "1.1.0",
  "name" : "CS_TW_LTC_Case_Source",
  "title" : "長照 SDK－申請來源（暫行）",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-17T17:33:17+08:00",
  "publisher" : "經濟部產業發展署",
  "contact" : [{
    "name" : "經濟部產業發展署",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ida.gov.tw/"
    }]
  }],
  "description" : "申請來源常見分類（待以 Excel 實值更新）。",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 4,
  "concept" : [{
    "code" : "hospital-referral",
    "display" : "醫院轉介"
  },
  {
    "code" : "self-apply",
    "display" : "自行申請"
  },
  {
    "code" : "center-referral",
    "display" : "照管中心轉介"
  },
  {
    "code" : "other",
    "display" : "其他"
  }]
}

```
