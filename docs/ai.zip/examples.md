# Examples - 臺灣長期照顧實作指引(TW LTC IG) v1.1.0

* [**Table of Contents**](toc.md)
* **Examples**

## Examples

### 範例

* [CMS評估個案範例](Patient-ltc-patient-cms-example.md)
* [SOF問卷](Questionnaire-ltc-questionnaire-sof.md)
* [SOF問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-sof-example.md)
* [主要照護者工作與支持問卷](Questionnaire-ltc-questionnaire-caregiver-support.md)
* [主要照顧者範例](RelatedPerson-ltc-related-person-primary-caregiver-example.md)
* [主要照顧者負荷問卷](Questionnaire-ltc-questionnaire-caregiver-load.md)
* [家庭照顧者狀況範例](Condition-ltc-condition-caregiver-family-example.md)
* [居家環境與社會參與問卷](Questionnaire-ltc-questionnaire-society.md)
* [居家環境與社會參與問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-society-example.md)
* [工具性日常活動功能問卷](Questionnaire-ltc-questionnaire-iadl.md)
* [工具性日常活動功能問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-iadl-example.md)
* [心率量測範例](Observation-pasport-observation-heart-rate-example.md)
* [日常生活能力評估問卷回覆範例](QuestionnaireResponse-ltc-questionnaire-response-adl-example.md)
* [日常生活能力評估問卷範例](Questionnaire-ltc-questionnaire-adl-assessment-example.md)
* [溝通表達能力問卷](Questionnaire-ltc-questionnaire-communication.md)
* [溝通表達能力問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-communication-example.md)
* [無壓傷狀況範例](Condition-ltc-condition-crush-none-example.md)
* [照顧管理評估量表住民範例](Patient-ltc-patient-cms-chen-ming-hui-example.md)
* [照顧管理評估量表文件打包範例](Bundle-ltc-bundle-cms-example.md)
* [照顧管理評估量表文件架構範例](Composition-ltc-composition-cms-example.md)
* [照顧者問卷](Questionnaire-ltc-questionnaire-caregiver.md)
* [照顧者支持問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-caregiver-support-example.md)
* [照顧者負荷問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-caregiver-load-example.md)
* [特殊複雜照護需要問卷](Questionnaire-ltc-questionnaire-special-care.md)
* [特殊複雜照護需要問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-special-care-example.md)
* [短期記憶力問卷](Questionnaire-ltc-questionnaire-memory.md)
* [短期記憶力問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-memory-example.md)
* [第二期壓傷範例](Condition-ltc-condition-crush-stage2-example.md)
* [糖尿病病情範例](Condition-ltc-condition-diabetes-example.md)
* [糖尿病藥物給藥範例](MedicationAdministration-ltc-medication-administration-metformin-example.md)
* [肢體障礙類型範例](Condition-ltc-condition-disability-type-limb-example.md)
* [與家人同住居住狀況範例](Condition-ltc-condition-residence-not-alone-example.md)
* [血壓量測範例（LTC）](Observation-ltc-observation-blood-pressure-example.md)
* [血壓量測範例（PASport）](Observation-pasport-observation-blood-pressure-example.md)
* [行動照顧計畫範例](CarePlan-ltc-careplan-mobility-example.md)
* [行動能力改善目標範例](Goal-ltc-goal-mobility-improvement-example.md)
* [認知功能與精神狀態問卷](Questionnaire-ltc-questionnaire-mental.md)
* [認知功能與精神狀態問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-mental-example.md)
* [跌倒紀錄範例](Observation-ltc-observation-falling-history-example.md)
* [身心障礙手冊持有狀態範例](Condition-ltc-condition-disability-example.md)
* [身體質量指數測量範例](Observation-pasport-observation-bmi-example.md)
* [身高量測範例](Observation-pasport-observation-height-example.md)
* [轉介ADL問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-adl-referral-example.md)
* [轉介IADL問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-iadl-referral-example.md)
* [轉介個案範例](Patient-ltc-patient-referral-example.md)
* [轉介單住民範例](Patient-ltc-patient-referral-chen-ming-hui-example.md)
* [轉介單居家服務計畫範例](CarePlan-ltc-careplan-referral-home-service-example.md)
* [轉介單文件打包範例](Bundle-ltc-bundle-referral-example.md)
* [轉介單文件架構範例](Composition-ltc-composition-referral-example.md)
* [轉介照顧者問卷回應範例](QuestionnaireResponse-ltc-questionnaire-response-caregiver-referral-example.md)
* [運動史記錄範例](Condition-pasport-condition-exercise-history-example.md)
* [運動治療服務請求範例](ServiceRequest-pasport-servicerequest-exercise-therapy-example.md)
* [運動目標－步行步數範例](Goal-pasport-goal-walking-steps-example.md)
* [運動計畫－步行運動範例](CarePlan-pasport-careplan-walking-exercise-example.md)
* [長期照顧住民範例](Patient-ltc-patient-chen-ming-hui.md)
* [長期照顧團隊範例](CareTeam-ltc-care-team-example.md)
* [長期照顧就醫紀錄範例](Encounter-ltc-encounter-example.md)
* [長期照顧機構範例](Organization-ltc-organization-example.md)
* [個案位置監測範例](Location-ltc-location-example.md)
* [異常事件警報範例](AdverseEvent-ltc-adverse-event-example.md)
* [長期照顧護理師範例](Practitioner-ltc-practitioner-nurse-example.md)
* [長期照顧護理師角色範例](PractitionerRole-ltc-practitioner-role-nurse-example.md)
* [長照醫事人員範例](Practitioner-ltc-practitioner-example.md)
* [需要照護協助狀況範例](Condition-ltc-condition-need-assistance-example.md)
* [骨骼肌重測量範例](Observation-pasport-observation-skeletal-muscle-mass-example.md)
* [體脂率測量範例](Observation-pasport-observation-body-fat-percentage-example.md)
* [體重量測範例](Observation-pasport-observation-weight-example.md)
* [鼻胃管管路狀況範例](Condition-ltc-condition-tube-nasogastric-example.md)
* [長期照護醫師意見書問卷範例](Questionnaire-ltc-questionnaire-aa12-example.md)
* [長期照護醫師意見書問卷回覆範例](QuestionnaireResponse-ltc-questionnaire-response-aa12-example.md)
* [長期照護醫師範例](Practitioner-ltc-practitioner-physician-aa12-example.md)
* [長期照護醫療機構範例](Organization-twcore-organization-hospital-aa12-example.md)
* [長照轉介服務請求範例](ServiceRequest-ltc-servicerequest-referral-example.md)
* [轉介確認任務範例](Task-ltc-task-referral-acceptance-example.md)

#### 居家護理照護管理系統

提供收案、評估、照護計畫、共照、多筆傷口、生命徵象及處理結果查詢範例。請參考 [居家護理主題](home-nursing.md)。

### 在宅急症照護

* [完成療程與結案文件](Bundle-hah-document.md)。
* [再次收案與轉院文件](Bundle-hah-transfer-document.md)。
* [情境說明及更多範例](hah.md)。

