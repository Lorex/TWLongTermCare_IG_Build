# 長照 SDK－長照福利身分 - 臺灣長期照顧實作指引(TW LTC IG) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **長照 SDK－長照福利身分**

## CodeSystem: 長照 SDK－長照福利身分 

| | |
| :--- | :--- |
| *Official URL*:http://ltc-ig.fhir.tw/CodeSystem/cs-tw-ltc-welfare-identity | *Version*:1.0.0 |
| Active as of 2026-04-02 | *Computable Name*:CS_TW_LTC_WelfareIdentity |

 
此 CodeSystem 定義長照 SDK 中的長照福利身分代碼。 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VS_TW_LTC_WelfareIdentity](ValueSet-vs-tw-ltc-welfare-identity.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "cs-tw-ltc-welfare-identity",
  "url" : "http://ltc-ig.fhir.tw/CodeSystem/cs-tw-ltc-welfare-identity",
  "version" : "1.0.0",
  "name" : "CS_TW_LTC_WelfareIdentity",
  "title" : "長照 SDK－長照福利身分",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-02T13:32:15+08:00",
  "publisher" : "經濟部產業發展署",
  "contact" : [{
    "name" : "經濟部產業發展署",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ida.gov.tw/"
    }]
  }],
  "description" : "此 CodeSystem 定義長照 SDK 中的長照福利身分代碼。",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 3,
  "concept" : [{
    "code" : "cat1",
    "display" : "第1類"
  },
  {
    "code" : "cat2",
    "display" : "第2類"
  },
  {
    "code" : "cat3",
    "display" : "第3類"
  }]
}

```
