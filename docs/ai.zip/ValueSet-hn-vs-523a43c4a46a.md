# 居家護理－是否存在多重用藥問題選項 - 臺灣長期照顧實作指引(TW LTC IG) v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **居家護理－是否存在多重用藥問題選項**

## ValueSet: 居家護理－是否存在多重用藥問題選項 

| | |
| :--- | :--- |
| *Official URL*:http://ltc-ig.fhir.tw/ValueSet/hn-vs-523a43c4a46a | *Version*:1.1.0 |
| Draft as of 2026-09-29 | *Computable Name*:HNAnswerVS523a43c4a46a |
| *Other Identifiers:*OID:2.25.232788398708565154741595025427832804600 | |

 
限定是否存在多重用藥問題可填入的 V5.0.16 選項。 

 **References** 

* [居家護理－藥物安全性評估邏輯模型](StructureDefinition-HNDrugSafetiesModel.md)
* [居家護理－藥物安全性評估表單](StructureDefinition-HNDrugSafetiesResponse.md)
* [居家護理－藥物安全性評估](Questionnaire-hn-drugsafeties.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "hn-vs-523a43c4a46a",
  "url" : "http://ltc-ig.fhir.tw/ValueSet/hn-vs-523a43c4a46a",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.25.232788398708565154741595025427832804600"
  }],
  "version" : "1.1.0",
  "name" : "HNAnswerVS523a43c4a46a",
  "title" : "居家護理－是否存在多重用藥問題選項",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-09-29T04:34:44+08:00",
  "publisher" : "經濟部產業發展署",
  "contact" : [{
    "name" : "經濟部產業發展署",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ida.gov.tw/"
    }]
  }],
  "description" : "限定是否存在多重用藥問題可填入的 V5.0.16 選項。",
  "compose" : {
    "include" : [{
      "system" : "http://ltc-ig.fhir.tw/CodeSystem/hn-answer",
      "concept" : [{
        "code" : "cda5930e53d54"
      },
      {
        "code" : "c736238e0d768"
      },
      {
        "code" : "c202b3c5f268b"
      },
      {
        "code" : "cc36b4792cdd2"
      }]
    }]
  }
}

```
