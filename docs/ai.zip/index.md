# Home - 臺灣長期照顧實作指引(TW LTC IG) v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://ltc-ig.fhir.tw/ImplementationGuide/tw.iii.ltc | *Version*:1.0.0 |
| Active as of 2026-03-01 | *Computable Name*:TaiwanLongTermCareImplementationGuide |

### 重要異動公告

**STU 1.0.0 重大變更（Breaking Changes）**

本版為首個正式試用版（Standard for Trial Use），包含以下與先前版本不相容的異動：

1. **Profile 命名統一**：所有 Profile 統一採用`LTC[ResourceType][Purpose]`命名規範（如`LTCCarePlanPayload`、`LTCBundlePayload`），舊名稱（如`CarePlanTWLTCPlanSDK`、`BundleTWLTCSDKPayload`）不再使用。
1. **CodeSystem/ValueSet 去除 SDK 後綴**：`CS-TW-LTC-CMSLevel-SDK`、`CS-TW-LTC-CaseStatus-SDK`等已改為`CS-TW-LTC-CMSLevel`、`CS-TW-LTC-CaseStatus`。
1. **Extension 整併**：`Export-PlanId`、`FrequencyLabel-SDK`已改用 FHIR 原生欄位取代；Incident 系列 Extension 已廢棄，改用`LTCAdverseEvent`Profile。
1. **異常事件通報**：原`Communication`-based Incident Profile 已全面遷移至`LTCAdverseEvent`，並新增`AdverseEventDescription`、`AdverseEventNotifMethod`、`AdverseEventAbout`三個 Extension。
1. **Common Base Profile 導入**：新增`LTCCompositionBase`、`LTCObservationAssessmentBase`、`LTCEpisodeOfCareBase`作為共用基礎 Profile。
1. **CoverageEligibilityResponse 合併**：SDK 版與 CS100 版合併為單一`LTCCoverageEligibilityResponse`。

實作者請參照新版 Profile 名稱與結構進行調整。

### 介紹

臺灣長期照顧實作指引（Taiwan Long Term Care Implementation Guide，簡稱TW LTC IG）採用HL7® FHIR® standard（Fast Healthcare Interoperability Resources）IG建置方法，在[FHIR R4.0.1](http://hl7.org/fhir/R4/)之標準基礎上，參考了[臺灣核心實作指引 （TW Core Implementation Guide）0.3.2](https://twcore.mohw.gov.tw/ig/twcore/index.html)、[美國長期照顧實作指引（Electronic Long-Term Services and Supports (eLTSS) Release 1 - US Realm, eLTSS） 2.0.0 - STU2](https://hl7.org/fhir/us/eltss/index.html) ，進一步定義適用於臺灣長期照顧資料交換需求的Resources（類似資料表）、其中的資料項目（意即欄位）、基數（意即0..1、0..*、1..1或1..*）、資料類型（文字、日期時間、代碼等）、可綁定的代碼（及其綁定的強制程度）及查詢參數等，旨在提供健康照護資訊系統開發與實作者以TW LTC IG為基礎，再進一步訂定其實務專案所需之資料交換格式以應用於專案中。TW LTC IG的實作方式有兩種：

1. **僅支援Profiles**：系統僅支援TW LTC Profiles以呈現健康照護相關資料。
1. **支援Profiles + RESTful互動**：系統支援TW LTC Profiles及RESTful互動以呈現健康照護相關資料。

### 背景

鑒於長期照顧機構端與醫院及衛生福利部電子病歷資料交換需求，故此版本 Taiwan LTC IG 以 FHIR R4.0.1 為基礎，同時繼承自 Taiwan LTC Profiles/ValueSet 與 TW Core Profiles/ValueSet，以最大程度滿足對電子病歷資料交換的相容性，並分別參考來自其他國家長期照顧實作指引、衛生福利部電子病歷相關規範，使制定之 IG 在除了符合聯測需求外，也盡可能符合臺灣的實作需求。

TW LTC IG內容將在未來的版本中持續更新，各版本亦將附有版本異動說明。所有經進一步定義的 Resources 或 Profiles，皆稱為Profiles，各 Profiles 依據其可被在地實際採用的程度與不再修改的程度，將標記其「成熟度（Maturity Level）」，被稱之為 FMM（根據眾所周知的CMM级別）。FMM 等級（level）可被實作者用来判斷一個規範文件的進階程度，也就是穩定度。以下是已被定義的 FMM 等級，實務上會視情況調整以符合定義：

**DRAFT 0** 此 Resource 或 Profile（規範文件） 已被發佈於目前的建置，這個等級意即草稿。

**FMM 1** 滿足 DRAFT 0 條件，而且此規範文件在建置的過程沒有任何的警語，負責的工作小組已指明他們認為這份規範文件基本上已完成並可供實作使用。

**FMM 2** 滿足 FMM 1 條件，而且此規範文件已被測試，並成功支援至少三套獨立系統之間的可互操作性（意即至少有三套系統實作此規範成功地互通資料），這些系統利用大部分的規範文件（例如至少80%的核心資料），使用基於此規範文件的至少一個聲明範圍的半真實資料及情境（例如在聯測）。這些互操作結果要求被報告及被工作小組接受。

**FMM 3** 滿足 FMM 2 條件，而且此規範文件已被工作小组驗證應遵從的《[Conformance Resource Quality Guidelines](https://confluence.hl7.org/display/FHIR/Conformance+QA+Criteria)》；已經通過一輪正式投票；至少有10位來自至少3家機構不同的實作者提出意見，並造成至少一項實質性的改變。

**FMM 4** 滿足 FMM 3 條件，而且此規範文件已正式出版（例如：FHIR實作指引），並已實際應用於多個雛型專案。同時，負責的工作小組同意此規範文件足夠穩定，在後續的非向下相容（non-backward compatible）的異動中需與實作者協商與諮詢。

**FMM 5** 滿足 FMM 4 條件，而且此規範文件於在 FMM 1 以上等級（意即：試用等級）的兩個正式出版品發佈週期中出版，並已實際應用於至少五套獨立的產品系統。

**Normative（規範）** 此規範文件已被認定為穩定。

TW LTC IG 中所有Profiles的FMM等級如下： 
1. **FMM 2**：以下 Profiles 已在 2025 專案聯測松中由至少 3 套獨立系統成功實作互操作：
* LTCPatient（5 系統）
* LTCObservationVitalSigns（5 系統）
* LTCObservationVitalSignsPanel（5 系統）
* LTCOrganization（5 系統）
* LTCPractitioner（5 系統）
* LTCQuestionnaireResponseMMSE（4 系統）
* LTCQuestionnaire（4 系統）
* LTCQuestionnaireResponse（4 系統）
* LTCQuestionnaireResponseCDR（3 系統）

1. **FMM 1**：以下 Profiles 已在聯測中由至少 1 套系統實作，工作小組認為可供實作使用：
* LTCMedicationAdministration（2 系統）
* LTCBundleCMS（2 系統）
* LTCCompositionCMS（2 系統）
* LTCPatientCMS（2 系統）
* LTCCondition（2 系統）
* LTCQuestionnaireResponseADL（2 系統）
* LTCQuestionnaireResponseIADL（2 系統）
* LTCQuestionnaireResponseAA01（2 系統）
* LTCQuestionnaireResponseAA02（2 系統）
* LTCObservationFallingHistory（2 系統）
* LTCGoal（2 系統）
* LTCCarePlan（2 系統）
* LTCQuestionnaireResponseAA12（2 系統）
* LTCPractitionerRole（2 系統）

1. **FMM 0 (DRAFT)**：其餘所有 Profiles 為草稿版本。
 

### 如何閱讀這個實作指引（IG）

 TW LTC IG 之網站架構圖如下圖所示。各功能說明如下：

* **[應用說明](index.md)**：TW LTC IG 介紹及背景說明。
* **[規範文件](artifacts.md)**：TW LTC IG 能力聲明、所有 Profiles 與查詢參數及操作定義、專門術語及 Extensions。 
* **[能力聲明](capability-statements.md) **：應用 TW LTC IG 於建置業務目的使用的 FHIR Server 時，該 FHIR Server 必須及建議應該支援的操作功能。 
* **[查詢參數及操作定義](searchparameters-and-operation.md) **：查詢 FHIR Server 的 Profiles時，針對各 Profiles可使用的查詢參數及操作定義。 
* **[邏輯模型](logical-models.md) **：TW LTC IG 的所有邏輯模型（Logical Models），各邏輯模型會定義相應情境下使用的所有資料欄位。為了便於實作者快速理解，資料欄位會使用易於理解的命名，實作者再透過邏輯模型中的功能頁籤「Mappings」瞭解各資料欄位實際使用本IG的哪個Profiles的哪個資料項目（element）。 
* **[FHIR Profiles及Extensions](profiles-and-extensions.md)**： 
* TW LTC IG 的所有 Profiles 之定義與範例及Extensions。
* 各資料項目不同實作強制程度的 Terminology。
* 各資料項目的限制（Constraints）。
* 查詢依據 TW LTC IG 實作之 FHIR Server 的特定 Profiles 時，可使用的查詢參數。
* 有哪些 Profiles 具有查詢參數以及 Server 必須支援哪些必要的查詢參數功能。
 
* **[專門術語](terminologies.md) **：TW LTC IG網站所使用的專門術語，包括代碼系統（Code Systems）及值集（Value Sets），內容主要依據全國專門術語服務平臺（TW terminology services）與長期照顧情境使用之術語建置。 
 
* **[範例](examples.md)**：TW LTC IG 的所有範例。
* **[結構定義與範例檔下載](downloads.md)**：實作者若不偏好使用 FHIR RESTful API 驗證資料是否遵從 Profiles，可直接下載所需的格式驗證檔，包括 XML、JSON 及 Turtle 三種格式，亦可於此下載完整範例。
* **[安全性](security.md)**：主要說明採用 TW LTC IG 網站進行實作時，有關資料存取授權的作法。
* **[驗證教學](validates.md)**：如何驗證實作檔是否遵從 TW LTC IG 規範。
* **[ 2025 專案聯測松](connectathon.md)**：本規範與 2025 專案聯測松的賽道整合資訊。
* **[聯測松結果](connectathon-result.md)**：2025 專案聯測松的驗證結果。

### 作者與貢獻者

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 作者 | v0.0.1 ~ v0.4.1 | 經濟部產業發展署（Industrial Development Administration, Ministry of Economic Affairs） | 楊宇凡（Yu-Fan Yang） | 矽塔資訊服務有限公司（Sitatech Information Services Co., Ltd） | [ceo@sita.tech](mailto:ceo@sita.tech) |
| 貢獻者 | v0.4.0 | 曹軒寧（Hsuan-Ning Tsao） | 矽塔資訊服務有限公司（Sitatech Information Services Co., Ltd） | [shannontsao@sita.tech](mailto:shannontsao@sita.tech) | |
| 貢獻者 | v0.0.1 ~ v0.2.1 | 李修安（Hsiu-An Lee） | 國家衛生研究院 - 癌症研究所（National Health Research Institutes - The National Institute of Cancer Research） | [billy72325@gmail.com](mailto:billy72325@gmail.com) | |
| 貢獻者 | v0.0.1 ~ v0.4.0 | 李祥豪（Siang-Hao Lee） | 九日生行動健康科技公司（9Rise International Mobile Health Technology Co., Ltd.） | [shvoidlee@gmail.com](mailto:shvoidlee@gmail.com) | |
| 貢獻者 | v0.3.0 ~ v0.4.0 | 楊宗翰（Chung-Han Yang） | 九日生行動健康科技公司（9Rise International Mobile Health Technology Co., Ltd.） |  | |
| 貢獻者 | v0.0.1 ~ v0.4.0 | 黃薰慧（Hsun-Hui Huang） | 財團法人資訊工業策進會 - 數位轉型研究院（Institute for Information Industry - Digital Transformation Research Institute） | [beatrice@iii.org.tw](mailto:beatrice@iii.org.tw) | |
| 貢獻者 | v0.3.0 | 張鈞亮 (Chun-Liang Chang) | 財團法人資訊工業策進會 - 數位轉型研究院（Institute for Information Industry - Digital Transformation Research Institute） | [liangglchang@iii.org.tw](mailto:liangglchang@iii.org.tw) | |
| 貢獻者 | v0.3.0 | 崔智萱 (Nicole Tsui) | 財團法人資訊工業策進會 - 數位轉型研究院（Institute for Information Industry - Digital Transformation Research Institute） | [nicolechtsui@iii.org.tw](mailto:nicolechtsui@iii.org.tw) | |

